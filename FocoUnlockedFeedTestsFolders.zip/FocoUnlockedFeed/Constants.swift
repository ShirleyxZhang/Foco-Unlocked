//
//  Constants.swift
//  FocoUnlockedFeed
//
//  Created by Madison Minsk on 3/18/16.
//  Copyright © 2016 Madison Minsk. All rights reserved.
//

import Foundation


let BASE_URL = "https://sweltering-torch-5367.firebaseio.com"