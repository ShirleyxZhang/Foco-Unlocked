//
//  FocoUnlockedFeedTests.swift
//  FocoUnlockedFeedTests
//
//  Created by Madison Minsk on 3/8/16.
//  Copyright © 2016 Madison Minsk. All rights reserved.
//

import XCTest
@testable import FocoUnlockedFeed

class FocoUnlockedFeedTests: XCTestCase {
    // MARK: FoodTracker Tests
    // Tests to confirm that the Meal initializer returns when no name 
    
    func testMealInitialization() {
        
        // Success case.
        let potentialItem = Meal(name: "Newest meal", photo: nil, upvoted: true)
        XCTAssertNotNil(potentialItem)
        
        
        // Failure cases.
        let noName = Meal(name: "", photo: nil, upvoted:false)
        XCTAssertNil(noName, "Empty name is invalid")
        
    }
    
    
}
